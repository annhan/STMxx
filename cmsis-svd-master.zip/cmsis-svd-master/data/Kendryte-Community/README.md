# SVD files for Kendryte chips

These files have not been provided by Kendryte. Instead, they have been created
from scratch from the available documentation.

  * k210.svd: copied from the Rust Embedded project and used with permission under
    the license. The original source is located at:
    https://github.com/riscv-rust/k210-pac/blob/master/k210.svd
