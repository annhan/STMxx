# SVD files for SiFive chips

These files have not been provided by SiFive. Instead, they have been created
from scratch from the available documentation.

  * e310x.svd: copied from the Rust Embedded project and used with permission under
    the license. The original source is located at:
    https://github.com/riscv-rust/e310x/blob/master/e310x.svd
